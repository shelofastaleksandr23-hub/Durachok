# Дурак

Карточная игра «Дурак» — HTML-игра в Android-обёртке (WebView) с игрой по Nearby Connections.

## Структура
- `app/src/main/assets/index.html` — сама игра
- `app/src/main/java/com/example/durak/` — `MainActivity` (WebView) и `NearbyBridge` (игра рядом по Bluetooth/Wi-Fi)

## Сборка APK
**Через GitHub:** вкладка *Actions* → *Build APK* → *Run workflow*, готовый `Durak.apk` будет в *Artifacts*. При пуше тега `v*` (например `v1.0`) APK прикрепляется к Release.

**Локально:** Android Studio (Open → папка проекта → Run) или
```
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

Требования: JDK 17, Android SDK 35.
